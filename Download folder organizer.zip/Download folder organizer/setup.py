from cx_Freeze import setup, Executable

setup(
    name="Organizer",
    version="1.0",
    description="Simple application to organize files into folders and clean up your files",
    executables=[Executable("orgonizerAPP.py", icon="Org.ico", base=None)],
)
